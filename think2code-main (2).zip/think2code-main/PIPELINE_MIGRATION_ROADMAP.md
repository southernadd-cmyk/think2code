# New Pipeline Migration Roadmap

## Current Situation

**Old Compiler**: ✅ Works perfectly, has all features
**New Pipeline**: ❌ Missing critical features, produces incorrect code

## Root Cause Analysis

The new pipeline was designed with a different architecture (IR-based) but was never fully implemented with all the features that were added to the old compiler over time. The gap is **systematic** - not just a few bugs, but fundamental missing functionality.

## Step-by-Step Migration Plan

### STEP 1: Add Implicit Loop Detection to Analysis Phase

**File**: `js/compiler.js`  
**Location**: `EnhancedFlowAnalyzer.analyze()` (line 1655)

**Current Code:**
```javascript
analyze() {
    const basicAnalysis = super.analyze();
    this.loopClassifications = this.loopClassifier.classifyAllLoops();
    
    return {
        ...basicAnalysis,
        loopClassifications: this.loopClassifications
    };
}
```

**Required Changes:**
1. Add `findImplicitForeverLoopHeaders()` method to `EnhancedFlowAnalyzer` (copy from `FlowchartCompiler`)
2. Call it in `analyze()` method
3. Store result in analysis object
4. Also add for-loop detection (call `detectForLoopPattern()` for all decisions)

**New Code:**
```javascript
analyze() {
    const basicAnalysis = super.analyze();
    this.loopClassifications = this.loopClassifier.classifyAllLoops();
    
    // ADD: Implicit loop detection (like old compiler)
    this.implicitLoopHeaders = this.findImplicitForeverLoopHeaders();
    
    // ADD: For-loop detection (like old compiler)
    this.forPatternCache = new Map();
    this.nodes
        .filter(n => n.type === "decision")
        .forEach(dec => {
            const info = this.detectForLoopPattern(dec.id);
            if (info && info.initNodeId) {
                this.forPatternCache.set(dec.id, info);
            }
        });
    
    return {
        ...basicAnalysis,
        loopClassifications: this.loopClassifications,
        implicitLoopHeaders: this.implicitLoopHeaders,  // NEW
        forPatternCache: this.forPatternCache  // NEW
    };
}
```

**Dependencies:**
- Need to copy `findImplicitForeverLoopHeaders()` from `FlowchartCompiler` (line 3928)
- Need to copy `detectForLoopPattern()` from `FlowchartCompiler` (line 4133)
- Need to copy helper methods: `markLoopBodyNodes()`, `findNodeInCycle()`, `pathLeadsTo()`, etc.

---

### STEP 2: Pass Implicit Loops to IR Builder

**File**: `js/compiler.js`  
**Location**: `EnhancedIRBuilder` constructor (line 2444)

**Current Code:**
```javascript
constructor(nodes, connections, flowAnalysis) {
    super(nodes, connections, flowAnalysis);
    this.loopClassifications = flowAnalysis.loopClassifications || new Map();
    
    this.breakManager = new BreakManager(
        this.nodes,
        this.connections,
        flowAnalysis,
        this.outgoingMap,
        new Map() // ❌ WRONG: Should be incomingMap
    );
}
```

**Required Changes:**
1. Store `implicitLoopHeaders` from flowAnalysis
2. Build `incomingMap` (need to call `buildMaps()` or get from flowAnalysis)
3. Pass `incomingMap` to BreakManager

**New Code:**
```javascript
constructor(nodes, connections, flowAnalysis) {
    super(nodes, connections, flowAnalysis);
    this.loopClassifications = flowAnalysis.loopClassifications || new Map();
    this.implicitLoopHeaders = flowAnalysis.implicitLoopHeaders || new Set();  // NEW
    this.forPatternCache = flowAnalysis.forPatternCache || new Map();  // NEW
    
    // FIX: Build incomingMap (or get from flowAnalysis)
    // flowAnalysis should have incomingMap from super.analyze()
    const incomingMap = flowAnalysis.incomingMap || this.buildIncomingMap();
    
    this.breakManager = new BreakManager(
        this.nodes,
        this.connections,
        flowAnalysis,
        this.outgoingMap,
        incomingMap  // FIXED
    );
}

buildIncomingMap() {
    const map = new Map();
    this.nodes.forEach(node => {
        map.set(node.id, []);
    });
    this.connections.forEach(conn => {
        const incoming = map.get(conn.to) || [];
        incoming.push({ from: conn.from, to: conn.to, port: conn.port });
        map.set(conn.to, incoming);
    });
    return map;
}
```

---

### STEP 3: Handle Implicit Loops in IR Builder

**File**: `js/compiler.js`  
**Location**: `EnhancedIRBuilder.buildNode()` (line 2524)

**Current Code:**
```javascript
buildNode(nodeId, visited, allowedIds, depth, activeLoops, excludeNodeId) {
    // ... checks ...
    
    // Check if this is a classified loop header
    const loopInfo = this.loopClassifications.get(nodeId);
    if (loopInfo) {
        return this.buildLoopFromClassification(nodeId, loopInfo, visited, allowedIds, activeLoops);
    }
    
    // ... rest of method
}
```

**Required Changes:**
1. Check if node is an implicit loop header BEFORE checking classified loops
2. Build implicit loop IR structure
3. Need to create `buildImplicitForeverLoop()` method

**New Code:**
```javascript
buildNode(nodeId, visited, allowedIds, depth, activeLoops, excludeNodeId) {
    // ... existing checks ...
    
    // NEW: Check for implicit loops FIRST
    if (this.implicitLoopHeaders && this.implicitLoopHeaders.has(nodeId)) {
        return this.buildImplicitForeverLoop(nodeId, visited, allowedIds, activeLoops);
    }
    
    // Check if this is a classified loop header
    const loopInfo = this.loopClassifications.get(nodeId);
    if (loopInfo) {
        return this.buildLoopFromClassification(nodeId, loopInfo, visited, allowedIds, activeLoops);
    }
    
    // ... rest of method
}

// NEW METHOD: Build implicit forever loop IR
buildImplicitForeverLoop(headerId, visited, allowedIds, activeLoops) {
    if (activeLoops.has(headerId)) {
        return null; // Already building this loop
    }
    
    activeLoops.add(headerId);
    visited.add(headerId);
    
    const headerNode = this.findNode(headerId);
    if (!headerNode) return null;
    
    // Build header statement (e.g., "count = count + 1")
    let headerStmt = null;
    if (headerNode.type === 'process' || headerNode.type === 'var') {
        headerStmt = new IRStatement(headerId, 'assignment', headerNode.text || '');
    }
    
    // Build loop body (everything until we loop back)
    const nextId = this.getSuccessor(headerId, 'next');
    const bodyProgram = new IRProgram();
    
    if (nextId) {
        // Build body until we reach header again
        const bodyStmt = this.buildNodeUntil(
            nextId,
            headerId,  // Stop when we reach header
            visited,
            allowedIds,
            activeLoops
        );
        if (bodyStmt) {
            // Add body statements to program
            // ... need to extract statements from bodyStmt
        }
    }
    
    // Create while-true loop IR
    const loopIR = new IRWhileTrue(headerId, bodyProgram);
    if (headerStmt) {
        // Header statement goes inside loop body
        bodyProgram.addStatement(headerStmt);
    }
    
    activeLoops.delete(headerId);
    return loopIR;
}
```

**Dependencies:**
- Need `IRWhileTrue` class (may need to create)
- Need `buildNodeUntil()` method (may need to create)
- Need to handle breaks in implicit loops

---

### STEP 4: Fix Break Detection for Implicit Loops

**File**: `js/compiler.js`  
**Location**: `EnhancedIRBuilder.buildIfStatement()` (line 2583)

**Current Code:**
```javascript
// Use BreakManager to determine if break should be added
if (loopHeaderId) {
    const loopType = this.getLoopType(loopHeaderId);
    // Create contextStack from loopHeaderId (IR Builder doesn't have full contextStack)
    const contextStack = loopHeaderId ? [`loop_${loopHeaderId}`] : [];
    const shouldBreak = this.breakManager.shouldAddBreak(
        trueNext,
        loopHeaderId,
        contextStack,
        loopType,
        converge
    );
    // ...
}
```

**Required Changes:**
1. Track context stack properly (including implicit loops)
2. Check if we're in an implicit loop
3. Use `while_true_with_breaks` loop type for implicit loops

**New Code:**
```javascript
// Need to track context stack through buildNode calls
buildNode(nodeId, visited, allowedIds, depth, activeLoops, excludeNodeId, contextStack = []) {
    // ... existing code ...
    
    // When building implicit loop, add to context
    if (this.implicitLoopHeaders && this.implicitLoopHeaders.has(nodeId)) {
        contextStack = [...contextStack, `implicit_${nodeId}`];
    }
    
    // When building regular loop, add to context
    if (loopInfo) {
        contextStack = [...contextStack, `loop_${nodeId}`];
    }
    
    // Pass contextStack to buildIfStatement
}

buildIfStatement(nodeId, node, visited, allowedIds, loopHeaderId, activeLoops, activeDecisions, excludeNodeId, contextStack = []) {
    // ... existing code ...
    
    // Use BreakManager to determine if break should be added
    if (loopHeaderId) {
        let loopType = this.getLoopType(loopHeaderId);
        
        // NEW: Check if it's an implicit loop
        if (this.implicitLoopHeaders && this.implicitLoopHeaders.has(loopHeaderId)) {
            loopType = 'while_true_with_breaks';
        }
        
        const shouldBreak = this.breakManager.shouldAddBreak(
            trueNext,
            loopHeaderId,
            contextStack,  // Now has proper context
            loopType,
            converge
        );
        // ...
    }
}
```

---

### STEP 5: Update Code Generator for Implicit Loops

**File**: `js/compiler.js`  
**Location**: `generateCodeFromIR()` (line 7093)

**Current Code:**
```javascript
switch (node.type) {
    case 'statement':
        // ...
        break;
    case 'if':
        // ...
        break;
    case 'while':
        // ...
        break;
    // ❌ NO case for 'while_true' or implicit loops
}
```

**Required Changes:**
1. Add case for `while_true` loop type
2. Handle breaks inside while-true loops
3. Ensure proper indentation

**New Code:**
```javascript
switch (node.type) {
    // ... existing cases ...
    
    case 'while_true':  // NEW
        lines.push(pad + 'while True:');
        if (node.body) {
            emit(node.body, indent + 4);
        } else {
            lines.push(pad + '    pass');
        }
        break;
    
    case 'break':  // NEW (if IRBreak exists)
        lines.push(pad + 'break');
        break;
}
```

---

### STEP 6: Add Graph Normalization

**File**: `js/compiler.js`  
**Location**: Before `EnhancedFlowAnalyzer` construction

**Current Code:**
```javascript
window.compileWithPipeline = function (nodes, connections, useHighlighting, debugMode = false) {
    const analyzer = new EnhancedFlowAnalyzer(nodes, connections);
    // ❌ NO normalization
}
```

**Required Changes:**
1. Copy `normalizeGraph()` from `FlowchartCompiler` (line 3673)
2. Call it before analysis

**New Code:**
```javascript
window.compileWithPipeline = function (nodes, connections, useHighlighting, debugMode = false) {
    // NEW: Normalize graph first
    const normalized = normalizeGraph(nodes, connections);
    
    const analyzer = new EnhancedFlowAnalyzer(normalized.nodes, normalized.connections);
    // ... rest
}

function normalizeGraph(nodes, connections) {
    // Copy implementation from FlowchartCompiler.normalizeGraph()
    // ...
}
```

---

### STEP 7: Add Post-Compilation Optimization

**File**: `js/compiler.js`  
**Location**: After `generateCodeFromIR()`

**Current Code:**
```javascript
window.compileWithPipeline = function (nodes, connections, useHighlighting, debugMode = false) {
    // ...
    const code = generateCodeFromIR(ir, { useHighlighting });
    return code;  // ❌ NO optimization
}
```

**Required Changes:**
1. Copy `optimizeGeneratedCode()` from `FlowchartCompiler` (line 5077)
2. Call it after code generation

**New Code:**
```javascript
window.compileWithPipeline = function (nodes, connections, useHighlighting, debugMode = false) {
    // ...
    let code = generateCodeFromIR(ir, { useHighlighting });
    
    // NEW: Optimize generated code
    code = optimizeGeneratedCode(code);
    
    return code;
}
```

---

## Testing Strategy

After each step, test with:

1. **flowchart45.json** - Should produce `while True:` with breaks
2. **atm.json** - Should produce `while-else` pattern
3. **forloop.json** - Should produce `for` loop
4. **movement-gameloop.json** - Complex game loop

Compare output with old compiler - should be semantically equivalent (may have minor formatting differences).

---

## Estimated Effort

- **Step 1**: 2-3 hours (copy methods, integrate)
- **Step 2**: 1-2 hours (fix constructor, build maps)
- **Step 3**: 4-6 hours (implement implicit loop IR building)
- **Step 4**: 3-4 hours (fix break detection)
- **Step 5**: 2-3 hours (update code generator)
- **Step 6**: 1-2 hours (add normalization)
- **Step 7**: 1-2 hours (add optimization)

**Total**: ~15-22 hours of focused work

---

## Priority Order

1. **Step 1** - Without implicit loop detection, nothing else matters
2. **Step 2** - Need proper data structures
3. **Step 3** - Core functionality
4. **Step 4** - Critical for correctness
5. **Step 5** - Output generation
6. **Step 6 & 7** - Polish and optimization

---

## Success Criteria

✅ All test cases pass  
✅ Generated code is semantically equivalent to old compiler  
✅ No regressions  
✅ Code quality is maintained or improved
