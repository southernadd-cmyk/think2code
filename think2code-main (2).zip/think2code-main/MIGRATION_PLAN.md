# Migration Plan: Old Architecture → New Pipeline Architecture

## Current Status

- **Active**: Old `FlowchartCompiler` (monolithic, direct compilation)
- **Inactive**: New Pipeline (`EnhancedFlowAnalyzer` → `EnhancedIRBuilder` → `generateCodeFromIR`)
- **Test Page**: Now supports selecting between both architectures

## Migration Goals

1. Achieve feature parity between old and new architectures
2. Ensure all recent fixes work in new architecture
3. Switch default to new architecture once stable
4. Maintain backward compatibility during transition

## Phase 1: Feature Parity Analysis ✅

### Features in Old Architecture (Need to Port)

#### 1. Implicit Loop Detection ✅
- **Status**: Partially implemented
- **Location**: `EnhancedFlowAnalyzer` has `findImplicitForeverLoopHeaders()` but may need updates
- **Action**: Verify implicit loop detection works in new pipeline
- **Priority**: HIGH

#### 2. Break Management ✅
- **Status**: Partially implemented
- **Location**: `EnhancedIRBuilder` has `BreakManager` but needs implicit loop support
- **Action**: 
  - Update `BreakManager` in `EnhancedIRBuilder` to handle implicit loops
  - Ensure `findCurrentLoopHeader()` works with implicit loops
- **Priority**: HIGH

#### 3. While-Else Pattern ✅
- **Status**: Needs verification
- **Location**: Should be handled by loop classification
- **Action**: Test with `atm.json` to ensure while-else works
- **Priority**: MEDIUM

#### 4. For-Loop Pattern Detection ✅
- **Status**: Should work (uses same detection logic)
- **Action**: Verify for-loop examples compile correctly
- **Priority**: MEDIUM

#### 5. Dominator-Based Loop Detection ✅
- **Status**: Implemented in `EnhancedFlowAnalyzer`
- **Action**: Verify it produces same results as old compiler
- **Priority**: MEDIUM

#### 6. Flowchart45 Pattern (While-True with Breaks) ❌
- **Status**: NOT IMPLEMENTED in new pipeline
- **Action**: 
  - Port implicit loop detection logic
  - Ensure breaks are added correctly
  - Test with flowchart45.json
- **Priority**: HIGH

## Phase 2: Port Critical Features

### Step 1: Implicit Loop Detection (Week 1)
- [ ] Verify `EnhancedFlowAnalyzer.findImplicitForeverLoopHeaders()` works correctly
- [ ] Test with flowchart45.json
- [ ] Ensure implicit loops are marked in analysis

### Step 2: Break Management for Implicit Loops (Week 1)
- [ ] Update `EnhancedIRBuilder` to detect implicit loops in contextStack
- [ ] Update `BreakManager.shouldAddBreak()` to handle implicit loops
- [ ] Test break insertion in while-true loops

### Step 3: Integration Testing (Week 2)
- [ ] Test all example flowcharts with new pipeline
- [ ] Compare output with old compiler
- [ ] Fix any discrepancies

## Phase 3: Code Generation Improvements

### IR → Code Generation
- [ ] Ensure `generateCodeFromIR()` handles all loop types correctly
- [ ] Verify break statements are emitted correctly
- [ ] Test while-else pattern in code generation

## Phase 4: Performance & Optimization

### Optimization Opportunities
- [ ] Profile new pipeline vs old compiler
- [ ] Optimize IR construction if needed
- [ ] Cache analysis results if beneficial

## Phase 5: Switch Default (Week 3-4)

### Pre-Switch Checklist
- [ ] All example flowcharts compile correctly
- [ ] All recent fixes verified in new pipeline
- [ ] Performance is acceptable
- [ ] No regressions in test suite

### Switch Process
1. Update `compileWithPipeline` default to use new pipeline
2. Keep old compiler available as fallback
3. Monitor for issues
4. Fix any bugs that arise

## Testing Strategy

### Test Cases to Verify

#### Basic Flowcharts
- [ ] Simple sequential code
- [ ] If/else statements
- [ ] Elif chains

#### Loops
- [ ] For loops (basic, descending, nested)
- [ ] While loops
- [ ] While-true loops
- [ ] While-else pattern (atm.json)
- [ ] Implicit loops (flowchart45.json)

#### Complex Cases
- [ ] Nested loops
- [ ] Multiple exit points
- [ ] Break statements in various contexts

### Comparison Method
1. Compile with old compiler → `old_output.py`
2. Compile with new pipeline → `new_output.py`
3. Compare outputs (semantic equivalence, not exact match)
4. Test both outputs with same inputs
5. Verify identical behavior

## Rollback Plan

If issues arise after switching:
1. Revert `compileWithPipeline` to use old compiler
2. Document issues found
3. Fix issues in new pipeline
4. Re-test before re-switching

## Success Criteria

✅ **Migration Complete When:**
- All test cases pass with new pipeline
- Performance is equal or better than old compiler
- Code quality is improved (more maintainable)
- All features work correctly
- No regressions

## Timeline Estimate

- **Week 1**: Port critical features (implicit loops, breaks)
- **Week 2**: Integration testing and bug fixes
- **Week 3**: Performance optimization and final testing
- **Week 4**: Switch default and monitor

**Total**: ~4 weeks for complete migration

## Notes

- Old compiler will remain available for comparison
- Test page allows easy switching between architectures
- Migration can be done incrementally (feature by feature)
- No breaking changes to external API (`compileWithPipeline`)
