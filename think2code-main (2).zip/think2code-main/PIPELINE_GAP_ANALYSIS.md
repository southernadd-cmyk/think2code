# New Pipeline Gap Analysis

## Executive Summary

The new pipeline (`EnhancedFlowAnalyzer` → `EnhancedIRBuilder` → `generateCodeFromIR`) is **significantly behind** the old compiler in terms of features and correctness. This document identifies all gaps and provides a roadmap for achieving feature parity.

## Critical Gaps Identified

### 1. ❌ **Implicit Loop Detection - COMPLETELY MISSING**

**Old Compiler:**
- Calls `findImplicitForeverLoopHeaders()` in constructor (line 3656)
- Stores result in `this.implicitLoopHeaders`
- Uses this in `compileNode()` to detect implicit loops (line 5563)
- Has `compileImplicitForeverLoop()` method (line 5768)
- Handles flowchart45 pattern correctly

**New Pipeline:**
- `EnhancedFlowAnalyzer` does NOT call `findImplicitForeverLoopHeaders()`
- No implicit loop detection in analysis phase
- `EnhancedIRBuilder` has no knowledge of implicit loops
- `generateCodeFromIR()` cannot generate `while True:` loops for implicit patterns

**Impact:** Flowchart45 and similar patterns will NOT compile correctly.

**Fix Required:**
1. Add `findImplicitForeverLoopHeaders()` call to `EnhancedFlowAnalyzer.analyze()`
2. Store implicit loop headers in analysis result
3. Pass implicit loop headers to `EnhancedIRBuilder`
4. Update `EnhancedIRBuilder` to detect and handle implicit loops
5. Update `generateCodeFromIR()` to generate `while True:` for implicit loops

---

### 2. ❌ **Break Management for Implicit Loops - MISSING**

**Old Compiler:**
- `BreakManager` initialized with `incomingMap` (line 3647)
- `findCurrentLoopHeader()` checks for `implicit_` prefix (line 6820-6829)
- All break detection locations check for implicit loops
- Uses `while_true_with_breaks` loop type for implicit loops

**New Pipeline:**
- `EnhancedIRBuilder` has `BreakManager` but:
  - No `incomingMap` passed (line 2454: `new Map()`)
  - No implicit loop detection in context
  - `findCurrentLoopHeader()` doesn't exist in IR Builder
  - No way to detect if we're in an implicit loop

**Impact:** Breaks won't be added correctly in implicit loops (flowchart45).

**Fix Required:**
1. Pass `incomingMap` to `BreakManager` in `EnhancedIRBuilder`
2. Add implicit loop detection to IR Builder context
3. Update break detection to handle implicit loops
4. Ensure loop type is set to `while_true_with_breaks` for implicit loops

---

### 3. ❌ **While-Else Pattern - UNKNOWN STATUS**

**Old Compiler:**
- `analyzeLoopStructure()` detects while-else pattern (line 4519)
- `compileLoop()` generates `while-else` code (line 5877-6139)
- Checks `hasBreakToEnd` to determine if else clause needed

**New Pipeline:**
- Loop classification may identify while loops
- But `generateCodeFromIR()` may not handle while-else correctly
- Need to verify IR structure supports while-else

**Impact:** `atm.json` may not compile with while-else pattern.

**Fix Required:**
1. Verify loop classification identifies while-else pattern
2. Ensure IR structure supports while-else
3. Update `generateCodeFromIR()` to emit while-else code

---

### 4. ❌ **For-Loop Pattern Detection - NEEDS VERIFICATION**

**Old Compiler:**
- `detectForLoopPattern()` called in constructor (line 3658-3665)
- Results cached in `forPatternCache`
- Used during compilation to generate `for` loops

**New Pipeline:**
- `EnhancedFlowAnalyzer` may not call for-loop detection
- `EnhancedIRBuilder` has `detectForLoopPattern()` but may not be called
- Need to verify for-loops are detected and classified correctly

**Impact:** For-loops may not be generated correctly.

**Fix Required:**
1. Ensure for-loop detection runs in analysis phase
2. Store for-loop patterns in analysis result
3. Verify IR Builder uses for-loop patterns
4. Test with forloop.json, countdown.json, 2loops.json

---

### 5. ❌ **Dominator-Based Loop Detection - DIFFERENT IMPLEMENTATION**

**Old Compiler:**
- Uses `computeDominators()` and `findBackEdgesAndLoops()` (line 3643-3644)
- Stores loop headers in `this.loopHeaders` (Set)
- Uses dominator analysis for loop detection

**New Pipeline:**
- `EnhancedFlowAnalyzer` extends `FlowAnalyzer` which has dominator analysis
- But uses `LoopClassifier` for loop classification instead
- May produce different results than old compiler

**Impact:** Different loops may be detected, causing compilation differences.

**Fix Required:**
1. Compare loop detection results between old and new
2. Ensure `LoopClassifier` produces same results as old compiler
3. Verify all loop types are classified correctly

---

### 6. ❌ **Code Generation - COMPLETELY DIFFERENT APPROACH**

**Old Compiler:**
- Direct string building in `compileNode()`, `compileDecision()`, `compileLoop()`, etc.
- Has specific methods for each pattern:
  - `compileImplicitForeverLoop()` - while True loops
  - `compileLoop()` - while/for loops with while-else support
  - `compileIfElse()` - if/else with break detection
  - `compileElifChainUntil()` - elif chains with break detection

**New Pipeline:**
- Uses IR → Code generation
- `generateCodeFromIR()` must handle all patterns
- May not have all the same pattern-specific logic

**Impact:** Code generation may be incorrect or incomplete.

**Fix Required:**
1. Compare generated code between old and new for all test cases
2. Identify missing patterns in `generateCodeFromIR()`
3. Port pattern-specific logic to code generator
4. Ensure all edge cases are handled

---

### 7. ❌ **Post-Compilation Optimization - MISSING**

**Old Compiler:**
- Calls `optimizeGeneratedCode()` at end (line 5073)
- Removes redundant code, optimizes structure

**New Pipeline:**
- No optimization step after code generation

**Impact:** Generated code may be less optimal.

**Fix Required:**
1. Add optimization step after `generateCodeFromIR()`
2. Port optimization logic from old compiler

---

### 8. ❌ **Graph Normalization - MISSING**

**Old Compiler:**
- Calls `normalizeGraph()` at start (line 5026)
- Normalizes connections, ports, etc.

**New Pipeline:**
- No normalization step

**Impact:** May fail on non-normalized graphs.

**Fix Required:**
1. Add normalization step before analysis
2. Port normalization logic from old compiler

---

### 9. ❌ **Node Skipping Logic - MISSING**

**Old Compiler:**
- Has `nodesToSkip` Set (line 3636)
- Skips for-loop init nodes (line 5548-5589)
- Has `isInitOfForLoop()` check (line 5748)

**New Pipeline:**
- No node skipping logic
- May compile nodes that should be skipped

**Impact:** For-loop init nodes may be compiled incorrectly.

**Fix Required:**
1. Add node skipping logic to IR Builder
2. Skip for-loop init nodes
3. Ensure skipped nodes are not in IR

---

### 10. ❌ **Context Stack Management - DIFFERENT**

**Old Compiler:**
- Uses `contextStack` array to track nested structures
- Tracks `loop_${nodeId}` and `implicit_${nodeId}`
- Used for break detection and loop header finding

**New Pipeline:**
- IR Builder may not use same context stack approach
- Break detection may not have proper context

**Impact:** Breaks may not be added correctly in nested structures.

**Fix Required:**
1. Ensure IR Builder maintains context stack
2. Pass context stack to BreakManager
3. Verify break detection uses context correctly

---

## Detailed Comparison: Old vs New

### Compilation Flow

**Old Compiler:**
```
1. normalizeGraph()
2. buildMaps()
3. computeDominators()
4. findBackEdgesAndLoops()
5. findImplicitForeverLoopHeaders() ← CRITICAL
6. detectForLoopPattern() for all decisions
7. compileNode(startNode) → recursive compilation
   - compileDecision() → handles loops, if/else
   - compileImplicitForeverLoop() → while True loops
   - compileLoop() → while/for loops
   - compileIfElse() → if/else with breaks
8. optimizeGeneratedCode()
```

**New Pipeline:**
```
1. EnhancedFlowAnalyzer.analyze()
   - super.analyze() → basic analysis
   - loopClassifier.classifyAllLoops() → loop classification
   - ❌ NO findImplicitForeverLoopHeaders()
   - ❌ NO for-loop detection
2. EnhancedIRBuilder.buildProgram()
   - buildNode() → builds IR
   - ❌ NO implicit loop handling
   - ❌ NO proper break detection for implicit loops
3. generateCodeFromIR()
   - emit() → generates code
   - ❌ May not handle all patterns
4. ❌ NO optimization
```

---

## Test Cases to Verify

### Critical Test Cases (Must Pass)

1. **flowchart45.json** - Implicit while-true loop with breaks
   - Expected: `while True:` with breaks
   - Current: Likely fails or produces wrong code

2. **atm.json** - While-else pattern
   - Expected: `while attempts < 3: ... else: print("locked")`
   - Current: Unknown

3. **movement-gameloop.json** - Complex game loop
   - Expected: Proper while loop with breaks
   - Current: Unknown

4. **forloop.json** - Basic for loop
   - Expected: `for i in range(...)`
   - Current: Needs verification

5. **countdown.json** - Descending for loop
   - Expected: `for i in range(10, 0, -1)`
   - Current: Needs verification

6. **2loops.json** - Nested for loops
   - Expected: Nested for loops
   - Current: Needs verification

---

## Migration Priority

### Phase 1: Critical Features (Week 1)
1. ✅ Add implicit loop detection to `EnhancedFlowAnalyzer`
2. ✅ Pass implicit loop headers to `EnhancedIRBuilder`
3. ✅ Update IR Builder to handle implicit loops
4. ✅ Fix break management for implicit loops
5. ✅ Update code generator for implicit loops

### Phase 2: Core Features (Week 2)
1. ✅ Verify for-loop detection works
2. ✅ Verify while-else pattern works
3. ✅ Add graph normalization
4. ✅ Add node skipping logic
5. ✅ Compare loop detection results

### Phase 3: Code Generation (Week 3)
1. ✅ Port all pattern-specific code generation
2. ✅ Ensure all test cases pass
3. ✅ Add post-compilation optimization
4. ✅ Fix any remaining edge cases

### Phase 4: Testing & Validation (Week 4)
1. ✅ Run all test cases
2. ✅ Compare outputs with old compiler
3. ✅ Fix discrepancies
4. ✅ Performance testing

---

## Specific Code Changes Needed

### 1. EnhancedFlowAnalyzer.analyze()

```javascript
analyze() {
    const basicAnalysis = super.analyze();
    this.loopClassifications = this.loopClassifier.classifyAllLoops();
    
    // ADD THIS:
    this.implicitLoopHeaders = this.findImplicitForeverLoopHeaders();
    
    // ADD THIS: For-loop detection
    this.forPatternCache = new Map();
    this.nodes
        .filter(n => n.type === "decision")
        .forEach(dec => {
            const info = this.detectForLoopPattern(dec.id);
            if (info && info.initNodeId) {
                this.forPatternCache.set(dec.id, info);
            }
        });

    return {
        ...basicAnalysis,
        loopClassifications: this.loopClassifications,
        implicitLoopHeaders: this.implicitLoopHeaders,  // ADD THIS
        forPatternCache: this.forPatternCache  // ADD THIS
    };
}
```

### 2. EnhancedIRBuilder Constructor

```javascript
constructor(nodes, connections, flowAnalysis) {
    super(nodes, connections, flowAnalysis);
    this.loopClassifications = flowAnalysis.loopClassifications || new Map();
    this.implicitLoopHeaders = flowAnalysis.implicitLoopHeaders || new Set();  // ADD THIS
    
    // FIX THIS: Pass incomingMap
    this.buildMaps();  // Need to build incomingMap
    this.breakManager = new BreakManager(
        this.nodes,
        this.connections,
        flowAnalysis,
        this.outgoingMap,
        this.incomingMap  // FIX: Don't use new Map()
    );
}
```

### 3. EnhancedIRBuilder.buildNode()

```javascript
buildNode(nodeId, visited, allowedIds, depth, activeLoops, excludeNodeId) {
    // ADD THIS: Check for implicit loops
    if (this.implicitLoopHeaders && this.implicitLoopHeaders.has(nodeId)) {
        return this.buildImplicitForeverLoop(nodeId, visited, allowedIds, activeLoops);
    }
    
    // ... rest of method
}
```

### 4. generateCodeFromIR()

Need to add handlers for:
- Implicit loops (while True)
- While-else pattern
- All loop types from classification

---

## Conclusion

The new pipeline is **significantly incomplete** and needs substantial work to achieve feature parity. The main issues are:

1. **Missing implicit loop detection** - Critical for flowchart45
2. **Incomplete break management** - Breaks won't work in implicit loops
3. **Unknown code generation quality** - Need to test all patterns
4. **Missing optimization and normalization** - Code quality issues

**Recommendation:** Focus on Phase 1 (Critical Features) first, then systematically work through remaining phases. Use the test page to compare outputs at each step.
