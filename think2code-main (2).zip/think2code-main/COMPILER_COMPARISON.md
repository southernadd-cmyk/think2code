# Old Compiler vs New Pipeline - Detailed Comparison

## Old Compiler Process (`FlowchartCompiler.compile()`)

### Initialization Phase (Constructor)
1. **Build Maps** - `buildMaps()`
   - Creates `outgoingMap` and `incomingMap` from connections
   - Normalizes port names (true/false → yes/no)
   - Handles different connection field formats

2. **Dominator Analysis** - `computeDominators()`
   - Computes dominator sets for all nodes
   - Uses iterative fixed-point algorithm
   - Stores in `this.dominators` Map

3. **Loop Detection** - `findBackEdgesAndLoops()`
   - Finds back edges using dominator analysis
   - Identifies loop headers
   - Stores in `this.loopHeaders` Set

4. **Implicit Loop Detection** - `findImplicitForeverLoopHeaders()`
   - Detects cycles without decision nodes
   - Stores in `this.implicitLoopHeaders` Set
   - Critical for flowchart45 pattern

5. **For-Loop Pattern Detection**
   - Pre-scans all decision nodes
   - Calls `detectForLoopPattern()` for each
   - Caches results in `this.forPatternCache`
   - Marks init nodes for skipping

### Compilation Phase (`compile()`)
1. **Normalize Graph** - `normalizeGraph()`
   - Normalizes connection formats
   - Validates node/connection structure

2. **Rebuild Maps** - `buildMaps()`
   - Ensures maps are current

3. **Re-detect Implicit Loops** - `findImplicitForeverLoopHeaders()`
   - Updates implicit loop headers

4. **Re-detect For-Loops**
   - Re-scans decision nodes for for-loop patterns

5. **Compile Node** - `compileNode(startNode.id, ...)`
   - Recursive compilation starting from start node
   - Handles:
     - Implicit loops → `compileImplicitForeverLoop()`
     - Decision loops → `compileLoop()` or `compileIfElse()`
     - For loops → `compileLoop()` with for-loop logic
     - Regular nodes → direct code generation
   - Uses context stack for nested structures
   - Tracks visited nodes to prevent cycles

6. **Add End Highlight** (if highlighting enabled)

7. **Optimize Code** - `optimizeGeneratedCode()`
   - Simplifies mathematical expressions
   - Removes unnecessary parentheses

### Key Methods in Old Compiler
- `compileNode()` - Main recursive compilation
- `compileImplicitForeverLoop()` - Handles while True loops
- `compileLoop()` - Handles while/for loops with while-else
- `compileIfElse()` - Handles if/else with break detection
- `compileElifChainUntil()` - Handles elif chains
- `findImplicitForeverLoopHeaders()` - Detects implicit loops
- `detectForLoopPattern()` - Detects for-loop patterns
- `optimizeGeneratedCode()` - Post-compilation optimization

---

## New Pipeline Process

### Phase 1: Analysis (`EnhancedFlowAnalyzer.analyze()`)
1. **Basic Analysis** - `super.analyze()`
   - Builds maps (outgoing/incoming)
   - Computes dominators
   - Finds back edges and loops
   - **MISSING**: Does NOT call `findImplicitForeverLoopHeaders()`

2. **Loop Classification** - `loopClassifier.classifyAllLoops()`
   - Uses `LoopClassifier` to classify loops
   - Classifies as: for, while, while-true
   - Stores in `this.loopClassifications` Map
   - **MISSING**: Does NOT detect implicit loops

### Phase 2: IR Construction (`EnhancedIRBuilder.buildProgram()`)
1. **Build Program** - `buildProgram(startNodeId)`
   - Calls `buildNode()` starting from start node
   - Builds IR structure recursively

2. **Build Node** - `buildNode(nodeId, ...)`
   - Checks for loop classifications
   - Builds appropriate IR node type:
     - For loops → `IRFor`
     - While loops → `IRWhile`
     - If statements → `IRIf`
     - Regular nodes → `IRStatement`
   - **MISSING**: Does NOT handle implicit loops
   - **MISSING**: Break management may not work for implicit loops

### Phase 3: Code Generation (`generateCodeFromIR()`)
1. **Emit Code** - `emit(irProgram, indent)`
   - Traverses IR structure
   - Generates Python code for each IR node type
   - **MISSING**: Does NOT handle while-else pattern properly
   - **MISSING**: May not handle all loop patterns correctly

2. **MISSING**: No post-compilation optimization

---

## Critical Missing Features in New Pipeline

### 1. ❌ Implicit Loop Detection
**Old Compiler:**
- Calls `findImplicitForeverLoopHeaders()` in constructor
- Calls it again in `compile()`
- Uses it in `compileNode()` to detect implicit loops
- Generates `while True:` loops for implicit patterns

**New Pipeline:**
- Does NOT call `findImplicitForeverLoopHeaders()` anywhere
- No implicit loop detection in analysis phase
- Cannot generate `while True:` for implicit patterns
- **Impact**: flowchart45.json and similar patterns will fail

### 2. ❌ Break Management for Implicit Loops
**Old Compiler:**
- `BreakManager` initialized with `incomingMap`
- `findCurrentLoopHeader()` checks for `implicit_` prefix
- Handles breaks in implicit loops correctly

**New Pipeline:**
- `BreakManager` exists but may not handle implicit loops
- No implicit loop headers passed to BreakManager
- **Impact**: Breaks in implicit loops won't work

### 3. ❌ While-Else Pattern
**Old Compiler:**
- `compileLoop()` detects while-else pattern
- Generates `while condition: ... else: ...` correctly

**New Pipeline:**
- `generateCodeFromIR()` has basic while-else support
- But may not detect the pattern correctly in IR construction
- **Impact**: atm.json (while-else) may not work

### 4. ❌ Post-Compilation Optimization
**Old Compiler:**
- Calls `optimizeGeneratedCode()` at end
- Simplifies expressions, removes redundant code

**New Pipeline:**
- No optimization step
- **Impact**: Generated code may be less clean

### 5. ❌ Graph Normalization
**Old Compiler:**
- Calls `normalizeGraph()` at start of `compile()`
- Normalizes connection formats

**New Pipeline:**
- No normalization step
- **Impact**: May fail with non-standard connection formats

### 6. ❌ For-Loop Pattern Detection
**Old Compiler:**
- Pre-detects for-loop patterns in constructor
- Re-detects in `compile()`
- Uses `detectForLoopPattern()` method

**New Pipeline:**
- Uses `LoopClassifier.classifyForLoop()` which may work
- But may not have all the same logic
- **Impact**: For loops may not be detected correctly

---

## Process Flow Comparison

### Old Compiler Flow:
```
Constructor:
  1. buildMaps()
  2. computeDominators()
  3. findBackEdgesAndLoops()
  4. findImplicitForeverLoopHeaders() ✅
  5. detectForLoopPattern() for all decisions ✅

compile():
  1. normalizeGraph() ✅
  2. buildMaps()
  3. findImplicitForeverLoopHeaders() ✅
  4. detectForLoopPattern() for all decisions ✅
  5. compileNode(startNode) → recursive compilation
     - Handles implicit loops ✅
     - Handles for loops ✅
     - Handles while-else ✅
     - Handles breaks ✅
  6. Add end highlight
  7. optimizeGeneratedCode() ✅
```

### New Pipeline Flow:
```
compileWithPipeline():
  Phase 1: EnhancedFlowAnalyzer.analyze()
    1. super.analyze() → basic analysis
    2. loopClassifier.classifyAllLoops()
    3. ❌ NO findImplicitForeverLoopHeaders()
    4. ❌ NO detectForLoopPattern() pre-scan
  
  Phase 2: EnhancedIRBuilder.buildProgram()
    1. buildNode(startNode) → builds IR
    2. ❌ NO implicit loop handling
    3. ❌ May not handle breaks correctly
  
  Phase 3: generateCodeFromIR()
    1. emit(irProgram) → generates code
    2. ❌ NO while-else pattern detection
    3. ❌ NO optimization
```

---

## What Needs to Be Ported

### High Priority (Critical for Basic Functionality)
1. ✅ Add `findImplicitForeverLoopHeaders()` to `EnhancedFlowAnalyzer.analyze()`
2. ✅ Pass implicit loop headers to `EnhancedIRBuilder`
3. ✅ Update `EnhancedIRBuilder.buildNode()` to handle implicit loops
4. ✅ Update `generateCodeFromIR()` to generate `while True:` for implicit loops
5. ✅ Fix break management for implicit loops

### Medium Priority (Important Features)
6. ✅ Add `normalizeGraph()` call before analysis
7. ✅ Add `optimizeGeneratedCode()` call after code generation
8. ✅ Verify for-loop detection works correctly
9. ✅ Verify while-else pattern works (atm.json)

### Low Priority (Nice to Have)
10. ✅ Improve code generation quality
11. ✅ Add better error messages
12. ✅ Performance optimization

---

## Test Cases to Verify

### Must Pass (Critical)
- [ ] flowchart45.json - Implicit while-true loop with breaks
- [ ] atm.json - While-else pattern
- [ ] forloop.json - Basic for loop
- [ ] countdown.json - Descending for loop
- [ ] WhileTrue.json - Explicit while-true loop

### Should Pass (Important)
- [ ] 2loops.json - Nested for loops
- [ ] whileloop.json - Basic while loop
- [ ] movement-gameloop.json - Complex game loop
- [ ] basicIF.json - Simple if/else
- [ ] maxOfThree.json - Complex if/elif chain

### Nice to Pass (Edge Cases)
- [ ] sumOfN.json - Accumulator pattern
- [ ] welcome.json - Simple linear flow
