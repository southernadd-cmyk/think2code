# BreakManager Design Document

## Overview

The `BreakManager` class will centralize all break statement detection and insertion logic. This will ensure consistent behavior across all loop types and compilation paths.

## Goals

1. **Single Source of Truth**: All break detection logic in one place
2. **Consistency**: Same rules apply everywhere (IR Builder, Old Compiler, Elif chains)
3. **Loop Type Awareness**: Different rules for for/while/while-true loops
4. **Nested Loop Support**: Correctly handle breaks in nested loops
5. **Maintainability**: Easy to update break logic in one place

## Class Structure

```javascript
class BreakManager {
    constructor(nodes, connections, flowAnalysis) {
        this.nodes = nodes;
        this.connections = connections;
        this.flowAnalysis = flowAnalysis;
        this.outgoingMap = this.buildOutgoingMap(connections);
        this.incomingMap = this.buildIncomingMap(connections);
    }
    
    /**
     * Main entry point: Should a break be added to this branch?
     * 
     * @param {string} branchStartId - Node ID where the branch starts
     * @param {string} loopHeaderId - Loop header node ID (null if not in loop)
     * @param {Array<string>} contextStack - Current context stack (for nested loops)
     * @param {string} loopType - Type of loop: 'for', 'while', 'while_true', 'while_else'
     * @param {string} convergencePoint - Convergence point ID (if any)
     * @returns {boolean} - True if break should be added
     */
    shouldAddBreak(branchStartId, loopHeaderId, contextStack, loopType, convergencePoint = null) {
        // Implementation details below
    }
    
    /**
     * Check if branch loops back to header (NOT an exit)
     */
    branchLoopsBackToHeader(branchStartId, loopHeaderId) {
        // Implementation
    }
    
    /**
     * Check if branch reaches END (is an exit)
     */
    branchReachesEnd(branchStartId, loopHeaderId) {
        // Implementation
    }
    
    /**
     * Find which loop level this break should exit
     */
    findTargetLoopLevel(branchStartId, contextStack) {
        // Implementation
    }
    
    /**
     * Check if this is an early exit (for for-loops)
     */
    isEarlyExit(branchStartId, loopHeaderId) {
        // Implementation
    }
}
```

## Break Decision Logic

### Step 1: Basic Checks
```javascript
shouldAddBreak(branchStartId, loopHeaderId, contextStack, loopType, convergencePoint) {
    // 1. Must be inside a loop
    if (!loopHeaderId) return false;
    
    // 2. Must have a valid branch start
    if (!branchStartId) return false;
    
    // 3. Check if branch loops back to header (NOT an exit)
    if (this.branchLoopsBackToHeader(branchStartId, loopHeaderId)) {
        return false; // Branch loops back, not an exit
    }
    
    // Continue to step 2...
}
```

### Step 2: Check if Branch Exits
```javascript
    // 4. Check if branch reaches END
    if (!this.branchReachesEnd(branchStartId, loopHeaderId)) {
        return false; // Branch doesn't exit
    }
    
    // Continue to step 3...
}
```

### Step 3: Loop Type Specific Rules
```javascript
    // 5. Loop type specific checks
    switch (loopType) {
        case 'for':
            // For loops: only break on early exits
            if (!this.isEarlyExit(branchStartId, loopHeaderId)) {
                return false; // Normal for-loop completion, no break
            }
            break;
            
        case 'while_else':
            // While-else: breaks are needed for early exits
            // Exit path becomes else clause
            break;
            
        case 'while_true':
        case 'while_true_with_breaks':
            // While-true: breaks are needed
            break;
            
        case 'while':
        case 'simple_while':
            // Regular while: breaks needed for early exits
            break;
            
        default:
            // Unknown loop type - be conservative
            break;
    }
    
    // Continue to step 4...
}
```

### Step 4: Nested Loop Handling
```javascript
    // 6. Check nested loops - ensure break exits correct loop
    const targetLoop = this.findTargetLoopLevel(branchStartId, contextStack);
    if (targetLoop && targetLoop !== loopHeaderId) {
        // Break should exit a different loop - don't add here
        return false;
    }
    
    // Continue to step 5...
}
```

### Step 5: Convergence Point Check
```javascript
    // 7. If convergence point exists, check if it's END
    if (convergencePoint) {
        const convNode = this.nodes.find(n => n.id === convergencePoint);
        if (convNode && convNode.type === 'end') {
            // Convergence is END - this is an exit
            return true;
        }
        // Convergence is not END - might be loop back or other node
        // Check if branch actually exits before convergence
        return this.branchReachesEnd(branchStartId, loopHeaderId);
    }
    
    // 8. All checks passed - add break
    return true;
}
```

## Helper Methods

### branchLoopsBackToHeader()
```javascript
branchLoopsBackToHeader(branchStartId, loopHeaderId) {
    if (!branchStartId || !loopHeaderId) return false;
    
    // Use canReach to check if branch can reach header
    // This is the same logic we've been using
    return this.canReach(branchStartId, loopHeaderId, new Set());
}
```

### branchReachesEnd()
```javascript
branchReachesEnd(branchStartId, loopHeaderId) {
    if (!branchStartId) return false;
    
    // Use reachesEndWithoutReturningToHeader
    // But ensure it doesn't go through header first
    return this.reachesEndWithoutReturningToHeader(branchStartId, loopHeaderId);
}
```

### findTargetLoopLevel()
```javascript
findTargetLoopLevel(branchStartId, contextStack) {
    // Find all loops in context stack
    const loopHeaders = contextStack
        .filter(ctx => ctx.startsWith('loop_'))
        .map(ctx => ctx.replace('loop_', ''));
    
    // Check which loop this branch actually exits
    // Start from innermost and work outward
    for (let i = loopHeaders.length - 1; i >= 0; i--) {
        const headerId = loopHeaders[i];
        
        // Check if branch exits this loop (reaches END without returning)
        if (this.branchReachesEnd(branchStartId, headerId)) {
            // Check if it loops back to this header
            if (!this.branchLoopsBackToHeader(branchStartId, headerId)) {
                return headerId; // This is the loop we exit
            }
        }
    }
    
    // No loop found - might exit all loops or not exit any
    return null;
}
```

### isEarlyExit()
```javascript
isEarlyExit(branchStartId, loopHeaderId) {
    // For for-loops, an early exit is when we break before
    // the loop would naturally complete
    
    // Check if this branch reaches END before the loop increment
    // This is a simplified check - might need more sophisticated logic
    return this.branchReachesEnd(branchStartId, loopHeaderId);
}
```

## Integration Points

### 1. IR Builder (`EnhancedIRBuilder`)
```javascript
// In buildIfStatement()
if (yesBranchExits && loopHeaderId) {
    const shouldBreak = this.breakManager.shouldAddBreak(
        trueNext,
        loopHeaderId,
        contextStack,
        this.getLoopType(loopHeaderId),
        converge
    );
    
    if (shouldBreak) {
        ifNode.thenBranch = this.appendBreakToBranch(ifNode.thenBranch, `${nodeId}_yes_break`);
    }
}
```

### 2. Old Compiler (`FlowchartCompiler`)
```javascript
// In compileIfElse()
if (inLoopBody) {
    const loopHeaderId = this.findCurrentLoopHeader(contextStack);
    const loopType = this.getLoopType(loopHeaderId);
    
    const shouldBreak = this.breakManager.shouldAddBreak(
        yesId,
        loopHeaderId,
        contextStack,
        loopType,
        convergencePoint
    );
    
    if (shouldBreak) {
        ifCode += `${"    ".repeat(indentLevel + 1)}break\n`;
    }
}
```

### 3. Elif Chain Compiler
```javascript
// In compileElifChainUntil()
const shouldBreak = this.breakManager.shouldAddBreak(
    elifYesId,
    loopHeaderId,
    contextStack,
    loopType,
    convergencePoint
);

if (shouldBreak) {
    elifCode += `${"    ".repeat(indentLevel + 1)}break\n`;
}
```

## Loop Type Detection

We need a method to get the loop type for a given header:

```javascript
getLoopType(loopHeaderId) {
    // Check if it's a for loop
    const forInfo = this.detectForLoopPattern(loopHeaderId);
    if (forInfo) {
        return 'for';
    }
    
    // Check loop analysis
    const loopInfo = this.flowAnalysis?.loopClassifier?.loopPatterns?.get(loopHeaderId);
    if (loopInfo) {
        switch (loopInfo.type) {
            case 'for': return 'for';
            case 'while': return 'while';
            case 'while_true': return 'while_true';
            default: return 'while';
        }
    }
    
    // Check if it has breaks and normal exit (while-else)
    const hasBreaks = this.checkForBreakToEnd(bodyId, loopHeaderId);
    const exitId = this.getExitId(loopHeaderId);
    if (hasBreaks && exitId) {
        const isNormalExit = this.isNormalExitPath(exitId, loopHeaderId);
        if (isNormalExit) {
            return 'while_else';
        }
    }
    
    // Default to simple while
    return 'while';
}
```

## Migration Strategy

### Phase 1: Create BreakManager (No Changes to Existing Code)
1. Create `BreakManager` class
2. Implement all helper methods
3. Test in isolation

### Phase 2: Add BreakManager to Compilers
1. Add `breakManager` instance to `FlowchartCompiler`
2. Add `breakManager` instance to `EnhancedIRBuilder`
3. Keep existing break logic (don't remove yet)

### Phase 3: Replace Break Logic Gradually
1. Replace break logic in `compileIfElse()` first
2. Test thoroughly
3. Replace break logic in `buildIfStatement()`
4. Test thoroughly
5. Replace break logic in `compileElifChainUntil()`
6. Test thoroughly

### Phase 4: Remove Old Logic
1. Remove old break detection methods
2. Clean up unused code
3. Final testing

## Testing Strategy

### Test Cases

1. **Simple While Loop with Break**
   - Loop with if statement that breaks
   - Should add break correctly

2. **While-Else Pattern**
   - Loop with break inside, normal exit path
   - Should add break, exit path becomes else

3. **For Loop**
   - Normal for loop (no break)
   - For loop with early exit (should break)
   - Should NOT add break for normal completion

4. **Nested Loops**
   - Break in inner loop (should exit inner)
   - Break in outer loop (should exit outer)
   - Break that exits both (should exit correct level)

5. **Elif Chains**
   - Elif chain in loop
   - Some branches exit, some loop back
   - Should only add breaks to exiting branches

6. **Convergence Points**
   - Multiple paths converging at END
   - Should add break only once

7. **Loop Back Detection**
   - Branch that loops back to header
   - Should NOT add break

## Edge Cases

1. **Empty Branches**: Branch with no code that exits
2. **Multiple Exits**: Branch with multiple paths, some exit, some don't
3. **Complex Nested Structures**: Multiple levels of nesting
4. **Implicit Loops**: Process nodes that create loops
5. **Break in Break**: Already has break statement

## Performance Considerations

- Cache loop type lookups
- Cache reachability checks (canReach results)
- Minimize graph traversals
- Use visited sets to prevent infinite loops

## Future Enhancements

1. **Continue Statements**: Similar logic for continue
2. **Return Statements**: Handle function returns
3. **Exception Handling**: Handle try/except with breaks
4. **Optimization**: Remove unnecessary breaks
