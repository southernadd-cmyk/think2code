# Compiler Architecture Explanation

## Current State (2024)

### Two Compiler Architectures Coexist

#### 1. **Old Architecture: `FlowchartCompiler`** (Currently Active)
- **Class**: `FlowchartCompiler` (line 3615)
- **Method**: `compile()` (line 5024)
- **Status**: ✅ **ACTIVE** - This is what `compileWithPipeline` currently uses
- **Approach**: Direct compilation from flowchart → Python code
- **Features**:
  - ✅ All recent fixes (implicit loop detection, break management, flowchart45 support)
  - ✅ Dominator-based loop detection
  - ✅ For-loop pattern detection
  - ✅ While-else pattern support
  - ✅ BreakManager integration
  - ✅ Implicit forever loop detection
  - ✅ Direct code generation (no intermediate representation)

**Flow**:
```
Flowchart → FlowchartCompiler.compile() → Python Code
```

#### 2. **New Architecture: Pipeline** (Currently Inactive)
- **Components**:
  - `EnhancedFlowAnalyzer` (line 1648) - Analysis phase
  - `EnhancedIRBuilder` (line 2443) - IR construction phase  
  - `generateCodeFromIR()` (line 7093) - Code generation phase
- **Status**: ❌ **INACTIVE** - Not currently used by `compileWithPipeline`
- **Approach**: Three-phase pipeline with Intermediate Representation (IR)
- **Features**:
  - ✅ Loop classification system
  - ✅ IR-based compilation
  - ✅ More modular architecture
  - ❌ Missing recent fixes (implicit loops, break management for implicit loops)
  - ❌ Not fully tested with complex flowcharts

**Flow**:
```
Flowchart → EnhancedFlowAnalyzer.analyze() → Analysis
         → EnhancedIRBuilder.buildProgram() → IR
         → generateCodeFromIR() → Python Code
```

## Why We Have Two Architectures

1. **Old Architecture**: Mature, battle-tested, has all recent fixes
2. **New Architecture**: Designed for better modularity and maintainability, but needs feature parity

## Current `compileWithPipeline` Implementation

```javascript
window.compileWithPipeline = function (nodes, connections, useHighlighting, debugMode = false) {
    // Currently uses OLD architecture
    const compiler = new FlowchartCompiler(nodes, connections, useHighlighting, debugMode);
    return compiler.compile();
};
```

## Key Differences

| Feature | Old Architecture | New Architecture |
|---------|-----------------|------------------|
| **Structure** | Monolithic class | Three-phase pipeline |
| **IR** | No IR (direct compilation) | Uses IR (IRProgram, IRStatement, etc.) |
| **Loop Detection** | Dominator-based + implicit loop detection | LoopClassifier with classifications |
| **Break Management** | BreakManager integrated | BreakManager exists but may need updates |
| **Implicit Loops** | ✅ Fully supported | ❓ Needs verification |
| **Code Generation** | Direct string building | IR → Code generation |
| **Maintainability** | Harder (large class) | Easier (modular) |
| **Testing** | Well-tested | Needs more testing |

## What Needs to Happen

1. **Short-term**: Keep using old architecture (it works)
2. **Medium-term**: Port all fixes to new architecture
3. **Long-term**: Switch to new architecture once feature parity is achieved
