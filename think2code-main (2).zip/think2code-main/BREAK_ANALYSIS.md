# Break Statement Analysis and Design

## Current State: Where Breaks Are Added

### 1. IR Builder (`EnhancedIRBuilder`) - Lines 2627-2709
- **Location**: `buildIfStatement()` method
- **When**: Inside a loop, when a branch exits to END
- **Conditions**:
  - `loopHeaderId` is set (inside a loop)
  - `yesBranchExits` or `noBranchExits` is true
  - `allPathsExitLoop()` returns true
  - `reachesEndDirectly()` returns true
  - Branch doesn't loop back to header (recently added check)
- **Method**: `appendBreakToBranch()` - appends `IRBreak` node to branch IR

### 2. Old Compiler (`FlowchartCompiler`) - Multiple locations

#### a. `compileIfElse()` - Lines 6247-6267, 6278-6298
- **When**: Convergence point is END node OR branch reaches END
- **Conditions**: 
  - `inLoopBody` is true
  - Branch doesn't loop back to header (recently added check)
  - Convergence point is END OR `reachesEndWithoutReturningToHeader()` returns true

#### b. `compileElifChain()` - Lines 6588-6593, 6621-6629
- **When**: Elif branch or else branch reaches END
- **Conditions**: Convergence point is END node and `inLoopBody` is true
- **Issue**: No check for looping back to header!

#### c. `compileLoop()` - Line 6078
- **When**: `while_true_with_breaks` loop type
- **Always adds**: `break` after exit condition check

### 3. Loop Body Detection
- `checkForBreakToEnd()` - Checks if loop body has paths to END
- `loopBodyHasEarlyExit()` - Checks for explicit early exits
- `reachesEndWithoutReturningToHeader()` - Checks if path reaches END without going through header

## Loop Types and Break Requirements

### 1. Simple While Loop (`simple_while`)
- **Pattern**: `while condition:`
- **Break needed**: Only if branch inside exits to END
- **Example**: atm.json - break needed when `guess == pin`

### 2. While-True with Breaks (`while_true_with_breaks`)
- **Pattern**: `while True:` with breaks inside
- **Break needed**: Multiple breaks at different exit points
- **Example**: flowchart45 (if it were a loop)

### 3. While-True Simple (`while_true_simple`)
- **Pattern**: `while True:` infinite loop
- **Break needed**: Only at natural exit condition
- **Example**: Game loops

### 4. For Loop (`for`)
- **Pattern**: `for i in range(...):`
- **Break needed**: Rarely - only for early exits
- **Issue**: Breaks might interfere with for-loop semantics

### 5. While-Else Pattern
- **Pattern**: `while condition: ... else: ...`
- **Break needed**: Inside loop body (early exit)
- **Else clause**: Runs when loop completes normally (no break)
- **Example**: atm.json

## Problems Identified

### Problem 1: Breaks Added Too Eagerly
- **Location**: `compileElifChain()` - no check for looping back to header
- **Impact**: Breaks added even when path loops back
- **Fix needed**: Add same loop-back check as in `compileIfElse()`

### Problem 2: Inconsistent Break Detection
- **IR Builder**: Uses `allPathsExitLoop()` + `reachesEndDirectly()`
- **Old Compiler**: Uses `reachesEndWithoutReturningToHeader()` only
- **Impact**: Different behavior in different code paths

### Problem 3: For Loops and Breaks
- **Issue**: For loops shouldn't have breaks added the same way
- **Impact**: Breaks might be added incorrectly in for loops
- **Fix needed**: Check loop type before adding breaks

### Problem 4: Nested Loops
- **Issue**: Breaks might exit wrong loop level
- **Impact**: Break exits outer loop instead of inner loop
- **Fix needed**: Track which loop level we're in

### Problem 5: Convergence Point Logic
- **Issue**: Breaks added at convergence points might be wrong
- **Impact**: Multiple paths converging might cause duplicate breaks
- **Fix needed**: Ensure breaks only added once per exit path

## Proposed Solution: Centralized Break Management

### Phase 1: Create Break Decision Framework

```javascript
class BreakManager {
    shouldAddBreak(branchStartId, loopHeaderId, contextStack) {
        // 1. Check if we're actually in a loop
        if (!loopHeaderId) return false;
        
        // 2. Check if branch loops back to header (NOT an exit)
        if (this.canReach(branchStartId, loopHeaderId)) {
            return false;
        }
        
        // 3. Check if branch reaches END
        if (!this.reachesEndWithoutReturningToHeader(branchStartId, loopHeaderId)) {
            return false;
        }
        
        // 4. Check loop type - some loops don't need breaks
        const loopType = this.getLoopType(loopHeaderId);
        if (loopType === 'for' && !this.isEarlyExit(branchStartId)) {
            return false; // For loops only break on early exits
        }
        
        // 5. Check nested loops - ensure break exits correct loop
        const targetLoop = this.findTargetLoop(branchStartId, contextStack);
        return targetLoop === loopHeaderId;
    }
    
    findTargetLoop(branchStartId, contextStack) {
        // Find which loop this break should exit
        // Should be the innermost loop that the branch actually exits
    }
}
```

### Phase 2: Unify Break Detection Logic

1. **Single source of truth** for break detection
2. **Consistent checks** across all code paths:
   - Check if branch loops back to header
   - Check if branch reaches END
   - Check loop type
   - Check nested loop context

### Phase 3: Fix Specific Issues

1. **Fix `compileElifChain()`**: Add loop-back check
2. **Fix for loops**: Don't add breaks unless early exit
3. **Fix nested loops**: Track loop levels correctly
4. **Fix convergence points**: Ensure single break per exit path

## Implementation Plan

### Step 1: Create BreakManager Class
- Centralize all break detection logic
- Single method: `shouldAddBreak()`
- Handles all edge cases

### Step 2: Replace All Break Detection
- Replace all `reachesEndWithoutReturningToHeader()` calls
- Replace all `canReach()` checks for loop-back
- Use BreakManager everywhere

### Step 3: Add Loop Type Awareness
- Pass loop type to break detection
- Different rules for for/while/while-true

### Step 4: Add Nested Loop Support
- Track loop hierarchy in contextStack
- Ensure breaks exit correct loop level

### Step 5: Testing
- Test all loop types
- Test nested loops
- Test while-else patterns
- Test for loops with/without breaks

## Questions to Answer

1. **Should for loops ever have breaks?** 
   - Yes, but only for early exits (like `if condition: break`)
   - Not for normal loop completion

2. **How to handle breaks in nested loops?**
   - Break should exit innermost loop that branch actually exits
   - Need to track which loop level we're breaking from

3. **When should while-else be used?**
   - When loop has breaks AND normal exit path
   - Exit path becomes else clause

4. **Should breaks be added at convergence points?**
   - Only if convergence point is END
   - Only if all paths to convergence exit the loop
