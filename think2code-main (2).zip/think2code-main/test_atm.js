const fs = require('fs');
const { FlowchartCompiler } = require('./js/compiler.js');

const flowchartData = JSON.parse(fs.readFileSync('flows/atm.json', 'utf8'));
const compiler = new FlowchartCompiler(flowchartData.nodes, flowchartData.connections);
const result = compiler.compile();
console.log('=== COMPILED RESULT ===');
console.log(result);